import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np

def mad(series):
    return (series - series.median()).abs().mean()

def calculate_weighted_median(data, weight):
    weighted_data = data * weight
    return weighted_data.median()

def plot_boxplot(data, column, title):
    order = ["default", "companion", "blur", "both"]
    sns.set_style("whitegrid")
    plt.figure(figsize=(8, 6))
    boxplot = sns.boxplot(x='condition', y=column, data=data, palette="colorblind")
    
    plt.title(title, fontsize=20)
    plt.ylabel('Scores', fontsize=18)
    plt.xlabel('VR Condition', fontsize=18, labelpad=10)
    plt.xticks(rotation=0, fontsize=16)
    plt.yticks(fontsize=16)
    
    plt.show()

def analyze_data(file_path):
    data = pd.read_csv(file_path, delimiter=';', encoding='ISO-8859-1')

    grouped_data = data.groupby('condition')

    analysis_results = {}

    total_scores_df = pd.DataFrame()
    total_weighted_scores_list = []

    #This has to change if question sequence or number changes!
    ITCorr = np.array([0.03, -0.14, 0.51, 0.33, 0.62, 0.59, 0.62, 0.49, -0.06, 0.42])

    for condition, group in grouped_data:
        analysis_results[condition] = {}
        total_scores = np.zeros(len(group))
        total_weighted_scores = np.zeros(len(group))

        for i, column in enumerate(data.columns[2:]):
            weighted_median_value = calculate_weighted_median(group[column], ITCorr[i])
            analysis_results[condition][column] = {
                'Median': group[column].median(),
                'MAD': mad(group[column]),
                'Median Weighted': weighted_median_value,
            }
            total_scores += group[column]
            total_weighted_scores += group[column] * ITCorr[i]

        analysis_results[condition]['Total Score'] = {
            'Median': np.median(total_scores),
            'MAD': mad(pd.Series(total_scores)),
            'Median Weighted': np.median(total_weighted_scores),
        }

        total_weighted_scores_list.extend([
            {'condition': condition, 'Total Weighted Score': score}
            for score in total_weighted_scores
        ])
        total_weighted_scores_df = pd.DataFrame(total_weighted_scores_list)

        temp_df = pd.DataFrame({'condition': [condition]*len(group), 'Total Score': total_scores})
        total_scores_df = pd.concat([total_scores_df, temp_df], ignore_index=True)

    return analysis_results, total_scores_df, total_weighted_scores_df


def plot_total_weighted_scores_boxplot(total_weighted_scores_df):
    order = ["default", "companion", "blur", "both"]
    sns.set_style("whitegrid")
    plt.figure(figsize=(10, 6))
    sns.boxplot(x='condition', y='Total Weighted Score', data=total_weighted_scores_df, palette="colorblind", order=order)
    plt.title("Total Weighted Presence Scores by Condition", fontsize=20)
    plt.ylabel('Total Weighted Score', fontsize=18)
    plt.xlabel('Condition', fontsize=18, labelpad=10)
    plt.xticks(rotation=0, fontsize=16)
    plt.yticks(fontsize=16)
    plt.show()

#Change file to use
file_path = 'CSV_PQ_neu.csv'

results, total_scores_df, total_weighted_scores_df = analyze_data(file_path)

for condition, scores in results.items():
    print(f"Condition: {condition}")
    for score_type, values in scores.items():
        print(f"  {score_type}:")
        for key, value in values.items():
            print(f"    {key}: {value}")
    print()

plot_total_weighted_scores_boxplot(total_weighted_scores_df)
