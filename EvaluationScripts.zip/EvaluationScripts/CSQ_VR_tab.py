import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

def mad(series):
    return (series - series.median()).abs().mean()

def plot_boxplot(data, column, title):
    sns.set_style("whitegrid")
    plt.figure(figsize=(8, 6))
    boxplot = sns.boxplot(x='Setup', y=column, data=data, palette="colorblind")
    
    plt.title(title, fontsize=20)
    plt.ylabel('Scores', fontsize=18)
    plt.xlabel('VR Condition', fontsize=18, labelpad=10)
    plt.xticks(rotation=0, fontsize=16)
    plt.yticks(fontsize=16)
    
    plt.show()


def analyze_data(file_path):
    data = pd.read_csv(file_path, delimiter=';')

    plot_boxplot(data, 'CSQ-VR Score', 'CSQ-VR Total Score Across VR Conditions')
    plot_boxplot(data, 'Category Score Oculomotor', 'CSQ-VR Oculomotor Score Across VR Conditions')
    plot_boxplot(data, 'Category Score Vestibular', 'CSQ-VR Vestibular Score Across VR Conditions')
    plot_boxplot(data, 'Category Score Nausea', 'CSQ-VR Nausea Score Across VR Conditions')

    total_score_column = 'CSQ-VR Score'
    oculomotor_score_column = 'Category Score Oculomotor'
    vestibular_score_column = 'Category Score Vestibular'
    nausea_score_column = 'Category Score Nausea'

    grouped_data = data.groupby('Setup')

    analysis_results = {}

    for condition, group in grouped_data:
        analysis_results[condition] = {
            'Total Score': {
                'Mean (SD)': f"{group[total_score_column].mean():.2f} ({group[total_score_column].std():.2f})",
                'Median': group[total_score_column].median(),
                'MAD': mad(group[total_score_column]),
                'Range': f"{group[total_score_column].min()} - {group[total_score_column].max()}",
                'Max Score': group[total_score_column].max()
            },
            'Oculomotor Score': {
                'Mean (SD)': f"{group[oculomotor_score_column].mean():.2f} ({group[oculomotor_score_column].std():.2f})",
                'Median': group[oculomotor_score_column].median(),
                'MAD': mad(group[oculomotor_score_column]),
                'Range': f"{group[oculomotor_score_column].min()} - {group[oculomotor_score_column].max()}",
                'Max Score': group[oculomotor_score_column].max()
            },
            'Vestibular Score': {
                'Mean (SD)': f"{group[vestibular_score_column].mean():.2f} ({group[vestibular_score_column].std():.2f})",
                'Median': group[vestibular_score_column].median(),
                'MAD': mad(group[vestibular_score_column]),
                'Range': f"{group[vestibular_score_column].min()} - {group[vestibular_score_column].max()}",
                'Max Score': group[vestibular_score_column].max()
            },
            'Nausea Score': {
                'Mean (SD)': f"{group[nausea_score_column].mean():.2f} ({group[nausea_score_column].std():.2f})",
                'Median': group[nausea_score_column].median(),
                'MAD': mad(group[nausea_score_column]),
                'Range': f"{group[nausea_score_column].min()} - {group[nausea_score_column].max()}",
                'Max Score': group[nausea_score_column].max()
            }
        }

    return analysis_results

#Change file to use
file_path = 'CSQ_NeueWerte.csv'

# CSQ_NeueWerte.csv
# ErgebnisseCons1Bereinigt.csv

results = analyze_data(file_path)
for condition, scores in results.items():
    print(f"Condition: {condition}")
    for score_type, values in scores.items():
        print(f"  {score_type}:")
        for key, value in values.items():
            print(f"    {key}: {value}")
    print()

